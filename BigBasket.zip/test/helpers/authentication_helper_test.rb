require 'test_helper'

class AuthenticationHelperTest < ActionView::TestCase
end
