require 'test_helper'

class AuthenticationControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
